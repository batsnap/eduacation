a=['aaa','aa']
if 'aa' in a:
    print(a)